# 1. 
setwd("C:\\Users\\it24101068\\Documents\\it24101068")
getwd()
Delivery.Times <- read.table("Exercise - Lab 05.txt", header = TRUE, sep=" ")
Delivery.Times

# 2. 
hist(Delivery.Times$Delivery, breaks = seq(20, 70, by = 5), right = TRUE, 
     main = "Histogram of Delivery Times", 
     xlab = "Delivery Times", 
     ylab = "Frequency")

# 3. 

# 4. 
cumulative_freq <- cumsum(table(cut(Delivery.Times$Delivery, breaks = seq(20, 70, by = 5), right = TRUE)))
plot(seq(22.5, 67.5, by = 5), cumulative_freq, 
     type = "o", 
     main = "Cumulative Frequency Polygon (Ogive)", 
     xlab = "Delivery Times", 
     ylab = "Cumulative Frequency", 
     pch = 16)
